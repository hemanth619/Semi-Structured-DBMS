package heap;

import global.SystemDefs;

public class XMLRecordRead {

	
	
	public static void main(String[] args) {
		
	}
}
