package xmldb;

public class InputTree {

	public XMLInputTreeNode root;
}
